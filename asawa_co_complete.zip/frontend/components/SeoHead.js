import Head from 'next/head';

/**
 * Reusable SEO component for setting common meta tags, OpenGraph data and
 * structured data.  Accepts title, description and optional canonical URL.
 */
export default function SeoHead({ title, description, canonical }) {
  const siteName = 'ASAWA and Co.';
  const fullTitle = title ? `${title} | ${siteName}` : siteName;
  return (
    <Head>
      <title>{fullTitle}</title>
      {description && <meta name="description" content={description} />}
      {/* Open Graph tags */}
      <meta property="og:title" content={fullTitle} />
      {description && <meta property="og:description" content={description} />}
      <meta property="og:type" content="website" />
      <meta property="og:url" content={canonical} />
      <meta property="og:site_name" content={siteName} />
      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      {description && <meta name="twitter:description" content={description} />}
      {/* Canonical URL */}
      {canonical && <link rel="canonical" href={canonical} />}
    </Head>
  );
}
