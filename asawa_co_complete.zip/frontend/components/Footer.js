export default function Footer() {
  return (
    <footer className="bg-gray-100 text-gray-600 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h3 className="font-semibold text-primary mb-2">ASAWA and Co.</h3>
          <p className="text-sm">
            We buy, we grind, we sell – pure &amp; fresh. Discover our range of flours,
            spices and dry fruits delivered straight to your doorstep.
          </p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Quick Links</h4>
          <ul className="space-y-1 text-sm">
            <li><a href="/shop" className="hover:text-primary">Shop</a></li>
            <li><a href="/blogs" className="hover:text-primary">Blog</a></li>
            <li><a href="/about" className="hover:text-primary">About Us</a></li>
            <li><a href="/contact" className="hover:text-primary">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">Contact</h4>
          <p className="text-sm">Hyderabad, Telangana, India</p>
          <p className="text-sm">Email: info@asawaandco.com</p>
        </div>
      </div>
      <div className="text-center py-4 text-xs bg-gray-50 border-t border-gray-200">
        &copy; {new Date().getFullYear()} ASAWA and Co. All rights reserved.
      </div>
    </footer>
  );
}
