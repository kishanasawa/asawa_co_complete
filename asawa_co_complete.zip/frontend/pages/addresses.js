import SeoHead from '../components/SeoHead';

export default function Addresses() {
  return (
    <>
      <SeoHead
        title="Saved Addresses"
        description="Manage your saved delivery addresses for faster checkout."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Saved Addresses</h1>
        <p>You have no saved addresses. Add an address during checkout to save it here.</p>
      </div>
    </>
  );
}
