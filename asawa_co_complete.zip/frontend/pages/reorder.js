import SeoHead from '../components/SeoHead';

export default function Reorder() {
  return (
    <>
      <SeoHead
        title="Reorder Products"
        description="Quickly reorder your favorite products from past orders."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Reorder Products</h1>
        <p>You have no past orders to reorder from yet.</p>
      </div>
    </>
  );
}
