import SeoHead from '../components/SeoHead';

export default function OrderHistory() {
  return (
    <>
      <SeoHead
        title="Order History"
        description="View your past orders and reorder your favorite products."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Order History</h1>
        <p>You have not placed any orders yet.</p>
      </div>
    </>
  );
}
