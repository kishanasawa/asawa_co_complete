import SeoHead from '../components/SeoHead';

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Aditi Sharma',
      message:
        'The atta from ASAWA and Co. makes the softest rotis. I love the aroma and taste!',
    },
    {
      name: 'Rahul Singh',
      message:
        'Their spices are incredibly fresh. The flavors are unmatched and remind me of my grandmother’s cooking.',
    },
    {
      name: 'Priya Kumar',
      message:
        'I ordered dry fruits for Diwali and the quality was superb. Highly recommended!',
    },
  ];
  return (
    <>
      <SeoHead
        title="Testimonials"
        description="See what our customers have to say about our products and service."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Customer Testimonials</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((item, index) => (
            <div key={index} className="bg-white shadow-md rounded-lg p-6">
              <p className="mb-2 text-gray-700">"{item.message}"</p>
              <p className="text-primary font-semibold">— {item.name}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
