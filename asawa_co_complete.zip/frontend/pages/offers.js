import SeoHead from '../components/SeoHead';

export default function Offers() {
  const offers = [
    {
      title: 'Festival Offer',
      description: 'Buy any 2 masala packs and get 1 free!',
      code: 'FESTIVALBOGO',
    },
    {
      title: 'Dry Fruits Discount',
      description: 'Flat ₹100 off on purchase of dry fruits worth ₹1000 or more.',
      code: 'DRY100OFF',
    },
  ];
  return (
    <>
      <SeoHead
        title="Offers & Coupons"
        description="Grab the latest deals and discounts on ASAWA and Co. products."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Current Offers & Coupons</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {offers.map((offer, index) => (
            <div key={index} className="bg-white shadow-md rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{offer.title}</h3>
              <p className="mb-2 text-gray-700">{offer.description}</p>
              <p className="font-mono bg-gray-100 px-2 py-1 inline-block rounded-sm">{offer.code}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
