import SeoHead from '../components/SeoHead';

export default function ShippingPolicy() {
  return (
    <>
      <SeoHead
        title="Shipping Policy"
        description="Learn about our shipping options, rates, and delivery times."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Shipping Policy</h1>
        <p className="mb-4">
          We strive to process and dispatch all orders within 1-2 business days. Shipping times
          may vary based on your location. Standard delivery typically takes 3-7 days.
        </p>
        <p className="mb-4">
          Shipping charges are calculated at checkout based on your order weight and delivery
          location. Free shipping is available on orders above a certain value.
        </p>
      </div>
    </>
  );
}
