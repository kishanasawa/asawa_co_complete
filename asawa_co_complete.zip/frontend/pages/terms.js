import SeoHead from '../components/SeoHead';

export default function Terms() {
  return (
    <>
      <SeoHead
        title="Terms & Conditions"
        description="Read the terms and conditions for using ASAWA and Co. services."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Terms & Conditions</h1>
        <p className="mb-4">
          These terms and conditions outline the rules and regulations for the use of ASAWA and
          Co. products and services. By accessing our website or purchasing our products, you
          agree to these terms. Please read them carefully.
        </p>
        <p className="mb-4">
          We reserve the right to update our terms at any time. Continued use of the website
          constitutes acceptance of the updated terms.
        </p>
      </div>
    </>
  );
}
