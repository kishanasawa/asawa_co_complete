import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';

export default function Checkout() {
  const [placing, setPlacing] = useState(false);
  const [message, setMessage] = useState('');
  const router = useRouter();

  const handleCheckout = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/login');
      return;
    }
    setPlacing(true);
    try {
      // This is a placeholder order with a single item; in a real app you would send cart items
      const items = [{ product_id: 1, quantity: 1, price: 10 }];
      const res = await axios.post(
        `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'}/api/orders`,
        { items },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMessage(`Order placed! Order ID: ${res.data.orderId}`);
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to place order');
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Checkout</h1>
      <p>This page would normally collect shipping details and display cart items.</p>
      <button
        onClick={handleCheckout}
        disabled={placing}
        className="mt-4 px-6 py-3 bg-primary text-white rounded-md hover:bg-secondary disabled:opacity-50"
      >
        {placing ? 'Placing Order...' : 'Place Order'}
      </button>
      {message && <p className="mt-4 text-green-600 font-medium">{message}</p>}
    </div>
  );
}
