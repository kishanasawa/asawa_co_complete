import { useState } from 'react';
import SeoHead from '../components/SeoHead';

export default function TrackOrder() {
  const [orderId, setOrderId] = useState('');
  const [status, setStatus] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // In a real application, call the API to fetch order status by ID
    if (orderId.trim() !== '') {
      // Placeholder statuses
      const statuses = ['Processing', 'Shipped', 'Delivered', 'Cancelled'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      setStatus(randomStatus);
    }
  };

  return (
    <>
      <SeoHead
        title="Track Order"
        description="Check the status of your ASAWA order by entering your Order ID."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Track Your Order</h1>
        <form onSubmit={handleSubmit} className="max-w-md">
          <label htmlFor="orderId" className="block text-sm font-medium text-gray-700 mb-2">
            Order ID
          </label>
          <input
            id="orderId"
            type="text"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            required
            className="w-full border rounded-md p-2 mb-4"
            placeholder="Enter your order ID"
          />
          <button type="submit" className="px-6 py-2 bg-primary text-white rounded-md hover:bg-secondary">
            Check Status
          </button>
        </form>
        {status && (
          <p className="mt-4 text-lg">
            Current status for order <strong>{orderId}</strong>: <span className="font-semibold">{status}</span>
          </p>
        )}
      </div>
    </>
  );
}
