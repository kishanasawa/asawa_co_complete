import SeoHead from '../components/SeoHead';

export default function GiftCards() {
  return (
    <>
      <SeoHead
        title="Gift Cards"
        description="Surprise your loved ones with ASAWA and Co. gift cards for any occasion."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Gift Cards</h1>
        <p className="mb-4">
          Give the gift of choice! Our gift cards can be redeemed for any product in our store.
          Whether it’s a birthday, anniversary or a festive celebration, ASAWA and Co. gift cards
          make the perfect present.
        </p>
        <p className="mb-4">
          Select the amount you wish to gift and complete your purchase at checkout. A digital
          gift card will be emailed to your recipient with a unique code.
        </p>
      </div>
    </>
  );
}
