import SeoHead from '../components/SeoHead';

export default function Reviews() {
  return (
    <>
      <SeoHead
        title="My Reviews"
        description="View and manage the product reviews you have written."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">My Reviews</h1>
        <p>You have not written any reviews yet.</p>
      </div>
    </>
  );
}
