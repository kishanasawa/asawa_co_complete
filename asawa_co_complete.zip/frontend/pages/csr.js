import SeoHead from '../components/SeoHead';

export default function CSR() {
  return (
    <>
      <SeoHead
        title="Corporate Social Responsibility"
        description="Our commitment to sustainability, community welfare and ethical sourcing."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Corporate Social Responsibility</h1>
        <p className="mb-4">
          At ASAWA and Co., we believe in giving back to the community and preserving the
          environment. Our CSR initiatives include supporting local farmers, reducing
          plastic usage and contributing to educational programs.
        </p>
        <p className="mb-4">
          We continually strive to improve our sustainability practices and partner with
          organisations that share our values.
        </p>
      </div>
    </>
  );
}
