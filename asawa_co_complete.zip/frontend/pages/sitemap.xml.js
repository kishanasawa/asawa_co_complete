export async function getServerSideProps({ res }) {
  // Generate a simple sitemap based on static routes.
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000';
  const pages = [
    '',
    '/shop',
    '/about',
    '/contact',
    '/faqs',
    '/testimonials',
    '/recipes',
    '/csr',
    '/events',
    '/offers',
    '/coupons',
    '/track-order',
    '/gift-cards',
    '/terms',
    '/privacy',
    '/refund',
    '/shipping',
    '/blogs',
    '/login',
    '/register',
    '/profile',
    '/wishlist',
    '/order-history',
    '/addresses',
    '/reorder',
    '/reviews',
  ];
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
    pages
      .map((page) => {
        const loc = `${baseUrl}${page}`;
        return `<url><loc>${loc}</loc></url>`;
      })
      .join('\n') +
    '\n</urlset>';
  res.setHeader('Content-Type', 'application/xml');
  res.write(sitemap);
  res.end();
  return { props: {} };
}

export default function Sitemap() {
  return null;
}
