import { useRouter } from 'next/router';
import SeoHead from '../../components/SeoHead';

// Placeholder recipes data; in a real app this would come from an API.
const recipeData = {
  'classic-roti': {
    title: 'Classic Roti',
    content:
      'Combine ASAWA whole wheat atta with water and a pinch of salt. Knead into a soft dough, divide into balls, roll out and cook on a hot tawa. Serve hot.',
  },
  'masala-khichdi': {
    title: 'Masala Khichdi',
    content:
      'Rinse rice and lentils. Cook with vegetables, haldi powder and garam masala. Add water and simmer until soft. Garnish with ghee and serve warm.',
  },
  'almond-energy-balls': {
    title: 'Almond Energy Balls',
    content:
      'Blend ASAWA almonds with dates and cocoa powder. Roll into balls and refrigerate. A perfect healthy snack!',
  },
};

export default function RecipePage() {
  const router = useRouter();
  const { slug } = router.query;
  const recipe = recipeData[slug];
  if (!recipe) {
    return (
      <div className="container mx-auto px-4 py-8">
        <SeoHead title="Recipe Not Found" />
        <h1 className="text-2xl font-bold mb-4">Recipe Not Found</h1>
        <p>Sorry, the recipe you are looking for does not exist.</p>
      </div>
    );
  }
  return (
    <div className="container mx-auto px-4 py-8">
      <SeoHead
        title={recipe.title}
        description={`Learn how to make ${recipe.title} using ASAWA and Co. products.`}
      />
      <h1 className="text-3xl font-bold mb-4">{recipe.title}</h1>
      <p className="text-gray-700 whitespace-pre-line">{recipe.content}</p>
    </div>
  );
}
