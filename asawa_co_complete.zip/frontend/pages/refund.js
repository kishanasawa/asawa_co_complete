import SeoHead from '../components/SeoHead';

export default function RefundPolicy() {
  return (
    <>
      <SeoHead
        title="Refund Policy"
        description="Review our refund and return policies for ASAWA and Co. products."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Refund & Return Policy</h1>
        <p className="mb-4">
          If you are not satisfied with your purchase, you can return the product within 7 days
          of delivery for a refund or exchange. Items must be unused and in their original
          packaging.
        </p>
        <p className="mb-4">
          To initiate a return, please contact our customer service team with your order number
          and reason for return. We will guide you through the process.
        </p>
      </div>
    </>
  );
}
