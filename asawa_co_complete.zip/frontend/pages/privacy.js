import SeoHead from '../components/SeoHead';

export default function PrivacyPolicy() {
  return (
    <>
      <SeoHead
        title="Privacy Policy"
        description="Understand how ASAWA and Co. collects and uses your personal information."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
        <p className="mb-4">
          At ASAWA and Co., your privacy is important to us. This policy explains how we collect,
          use, and protect your personal information when you use our website and services.
        </p>
        <p className="mb-4">
          We collect information you provide when placing an order, subscribing to our newsletter
          or contacting us. We do not share your information with third parties except as
          necessary to fulfill your orders.
        </p>
      </div>
    </>
  );
}
