import SeoHead from '../components/SeoHead';

export default function FAQs() {
  const faqs = [
    {
      question: 'What makes ASAWA products pure and fresh?',
      answer:
        'We source directly from trusted farms and mill our flours daily to ensure maximum freshness and nutritional value.',
    },
    {
      question: 'Do you offer international shipping?',
      answer:
        'Currently, we ship across India. International shipping options will be available soon.',
    },
    {
      question: 'Can I return or exchange my order?',
      answer:
        'Yes, please refer to our Refund Policy for details on how to initiate a return or exchange within 7 days of delivery.',
    },
  ];
  return (
    <>
      <SeoHead
        title="Frequently Asked Questions"
        description="Answers to common questions about our products, shipping and returns."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Frequently Asked Questions</h1>
        <div className="space-y-4">
          {faqs.map((item, index) => (
            <details key={index} className="border rounded-md p-4 bg-white shadow-sm">
              <summary className="font-semibold cursor-pointer">
                {item.question}
              </summary>
              <p className="mt-2 text-gray-700">{item.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </>
  );
}
