import SeoHead from '../components/SeoHead';

export default function About() {
  return (
    <>
      <SeoHead
        title="About Us"
        description="Learn more about ASAWA and Co., our history, mission and values."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">About ASAWA and Co.</h1>
        <p className="mb-4">
          ASAWA and Co. is dedicated to bringing you the finest flours, spices and dry fruits.
          With decades of experience in sourcing and grinding, we stand for purity and freshness.
        </p>
        <p className="mb-4">
          Our story began in the heart of Hyderabad, where our founders envisioned a brand
          that connects farmers directly with consumers. We believe in transparency,
          sustainability and community support.
        </p>
        <p className="mb-4">
          From humble beginnings to a thriving enterprise, our commitment remains the same:
          delivering quality you can trust. Thank you for being part of our journey.
        </p>
      </div>
    </>
  );
}
