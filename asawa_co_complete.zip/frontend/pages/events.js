import SeoHead from '../components/SeoHead';

export default function Events() {
  const events = [
    {
      title: 'Organic Farming Workshop',
      date: 'October 15, 2025',
      description:
        'Join us for a hands-on workshop on sustainable farming practices and learn how we source our ingredients.',
    },
    {
      title: 'Cooking with Spices',
      date: 'November 12, 2025',
      description:
        'A live cooking session where our chefs demonstrate recipes using ASAWA spices and flours.',
    },
  ];
  return (
    <>
      <SeoHead
        title="Events & Workshops"
        description="Stay updated on our upcoming events, workshops and community meet-ups."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Events & Workshops</h1>
        <div className="space-y-6">
          {events.map((event, index) => (
            <div key={index} className="bg-white shadow-md rounded-lg p-6">
              <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
              <p className="text-primary mb-1">{event.date}</p>
              <p className="text-gray-700">{event.description}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
