import SeoHead from '../components/SeoHead';

export default function Coupons() {
  const coupons = [
    { code: 'WELCOME10', description: '10% off on your first order' },
    { code: 'FESTIVE50', description: 'Flat ₹50 off on orders above ₹500' },
    { code: 'HEALTHY20', description: '20% off on all atta products' },
  ];
  return (
    <>
      <SeoHead
        title="Coupons"
        description="Apply our latest coupon codes to save on your purchases."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Available Coupons</h1>
        <div className="space-y-4">
          {coupons.map((coupon, index) => (
            <div key={index} className="bg-white shadow rounded-md p-4 flex justify-between items-center">
              <div>
                <h3 className="font-semibold text-lg">{coupon.code}</h3>
                <p className="text-gray-700">{coupon.description}</p>
              </div>
              <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary text-sm">
                Apply
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
