import Link from 'next/link';

// Generate a list of placeholder blog posts
const posts = Array.from({ length: 50 }, (_, i) => ({
  slug: `blog-post-${i + 1}`,
  title: `Sample Blog Post ${i + 1}`,
  excerpt: `This is a summary of blog post ${i + 1}. Learn more about our products and recipes.`,
}));

export default function BlogList() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-center">Our Blog</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {posts.map((post) => (
          <div key={post.slug} className="bg-white shadow-md rounded-lg p-4 hover:shadow-lg transition-shadow">
            <h3 className="font-semibold text-xl mb-2">{post.title}</h3>
            <p className="text-gray-600 mb-3">{post.excerpt}</p>
            <Link href={`/blogs/${post.slug}`} className="text-primary hover:underline text-sm">
              Read More
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
