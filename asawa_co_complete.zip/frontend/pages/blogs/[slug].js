import { useRouter } from 'next/router';

// Same posts array as in index. In a real app this would come from an API.
const posts = Array.from({ length: 50 }, (_, i) => ({
  slug: `blog-post-${i + 1}`,
  title: `Sample Blog Post ${i + 1}`,
  content: `# Blog Post ${i + 1}\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Cras sed turpis ac magna consequat suscipit. Praesent pharetra diam ac ante placerat, sit amet laoreet justo pulvinar. Proin at venenatis sapien. Vivamus efficitur iaculis maximus. Integer feugiat finibus est, non pharetra neque aliquet eget. Sed sit amet nisl in nunc fermentum varius a ut orci. Vivamus sit amet nisl ante.\n\n### Section\n\nThis is some example markdown content for blog post ${i + 1}.`,
}));

export default function BlogPost() {
  const router = useRouter();
  const { slug } = router.query;
  const post = posts.find((p) => p.slug === slug);
  if (!post) return <div className="container mx-auto px-4 py-8">Post not found</div>;
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">{post.title}</h1>
      <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: post.content.replace(/\n/g, '<br/>') }}></div>
    </div>
  );
}
