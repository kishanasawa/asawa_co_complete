import SeoHead from '../components/SeoHead';
import Link from 'next/link';

export default function Recipes() {
  const recipes = [
    {
      title: 'Classic Roti',
      slug: 'classic-roti',
      description:
        'A simple recipe for soft and fluffy rotis using our whole wheat atta.',
    },
    {
      title: 'Masala Khichdi',
      slug: 'masala-khichdi',
      description:
        'A comforting khichdi spiced with our garam masala and haldi powder.',
    },
    {
      title: 'Almond Energy Balls',
      slug: 'almond-energy-balls',
      description:
        'Easy no-bake energy balls made with premium almonds and dried fruits.',
    },
  ];
  return (
    <>
      <SeoHead
        title="Recipes & Tips"
        description="Delicious recipes and cooking tips using ASAWA and Co. products."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Recipes & Tips</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recipes.map((recipe) => (
            <div key={recipe.slug} className="bg-white shadow-md rounded-lg p-6">
              <h3 className="font-semibold text-xl mb-2">{recipe.title}</h3>
              <p className="text-gray-700 mb-4">{recipe.description}</p>
              <Link href={`/recipes/${recipe.slug}`} className="text-primary hover:underline text-sm">
                View Recipe
              </Link>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
