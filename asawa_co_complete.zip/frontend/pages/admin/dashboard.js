import SeoHead from '../../components/SeoHead';

export default function AdminDashboard() {
  return (
    <>
      <SeoHead
        title="Admin Dashboard"
        description="Overview of sales, orders, inventory and website analytics."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
        <p className="mb-4">This dashboard will display key metrics such as sales, orders, inventory levels and blog views.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Sales</h2>
            <p className="text-gray-700">Monthly sales data will appear here.</p>
          </div>
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Orders</h2>
            <p className="text-gray-700">Summary of orders placed by customers.</p>
          </div>
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Inventory</h2>
            <p className="text-gray-700">Current stock status and low stock alerts.</p>
          </div>
        </div>
      </div>
    </>
  );
}
