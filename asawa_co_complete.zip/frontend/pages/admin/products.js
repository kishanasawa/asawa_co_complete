import SeoHead from '../../components/SeoHead';
import Link from 'next/link';

export default function AdminProducts() {
  return (
    <>
      <SeoHead
        title="Product Management"
        description="Create, edit, and manage products in your catalog."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Product Management</h1>
        <Link
          href="#"
          className="inline-block mb-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary"
        >
          Add New Product
        </Link>
        <p className="mb-4">Product list and edit functionality will be implemented here.</p>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Name</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Category</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Price</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Stock</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">Whole Wheat Atta</td>
              <td className="border-t px-4 py-2">Atta</td>
              <td className="border-t px-4 py-2">₹250.00</td>
              <td className="border-t px-4 py-2">50</td>
              <td className="border-t px-4 py-2">
                <button className="text-primary hover:underline mr-2">Edit</button>
                <button className="text-red-600 hover:underline">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
