import SeoHead from '../../components/SeoHead';

export default function AdminInventory() {
  return (
    <>
      <SeoHead
        title="Inventory Management"
        description="Add or edit stock quantities and monitor inventory levels."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Inventory Management</h1>
        <p className="mb-4">This page will allow admins to update stock levels, set minimum/maximum quantities and receive low-stock alerts.</p>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Product</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Variant</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Quantity</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Min Qty</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Max Qty</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">Whole Wheat Atta</td>
              <td className="border-t px-4 py-2">1kg</td>
              <td className="border-t px-4 py-2">50</td>
              <td className="border-t px-4 py-2">10</td>
              <td className="border-t px-4 py-2">200</td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
