import SeoHead from '../../components/SeoHead';
import Link from 'next/link';

export default function AdminCMS() {
  return (
    <>
      <SeoHead
        title="CMS Pages"
        description="Manage static pages like About, Privacy Policy, Terms and more."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">CMS Page Management</h1>
        <Link href="#" className="inline-block mb-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary">
          Add New Page
        </Link>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Title</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Slug</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">About Us</td>
              <td className="border-t px-4 py-2">about</td>
              <td className="border-t px-4 py-2">
                <button className="text-primary hover:underline mr-2">Edit</button>
                <button className="text-red-600 hover:underline">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
