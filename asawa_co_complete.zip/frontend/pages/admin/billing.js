import { useState } from 'react';
import SeoHead from '../../components/SeoHead';

export default function AdminBilling() {
  const [searchTerm, setSearchTerm] = useState('');
  const [items, setItems] = useState([]);

  const addItem = () => {
    if (!searchTerm) return;
    // In real implementation, search the product list and add to items
    setItems((prev) => [
      ...prev,
      {
        name: searchTerm,
        quantity: 1,
        price: 100,
      },
    ]);
    setSearchTerm('');
  };

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <>
      <SeoHead
        title="Billing / POS"
        description="Create manual bills and process in-store sales using the POS screen."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Billing / POS</h1>
        <div className="mb-4 flex space-x-2">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search product by name or scan barcode"
            className="flex-1 border rounded-md p-2"
          />
          <button
            onClick={addItem}
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary"
          >
            Add Item
          </button>
        </div>
        <table className="min-w-full bg-white shadow rounded-lg mb-4">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Product</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Quantity</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Price</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Total</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index}>
                <td className="border-t px-4 py-2">{item.name}</td>
                <td className="border-t px-4 py-2">{item.quantity}</td>
                <td className="border-t px-4 py-2">₹{item.price.toFixed(2)}</td>
                <td className="border-t px-4 py-2">₹{(item.price * item.quantity).toFixed(2)}</td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td className="border-t px-4 py-2" colSpan="4">
                  No items added yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
        <div className="flex justify-end mb-4">
          <p className="text-xl font-semibold">Total: ₹{total.toFixed(2)}</p>
        </div>
        <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary" disabled>
          Generate Invoice
        </button>
      </div>
    </>
  );
}
