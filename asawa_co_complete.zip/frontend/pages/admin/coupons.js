import SeoHead from '../../components/SeoHead';

export default function AdminCoupons() {
  return (
    <>
      <SeoHead
        title="Coupon Management"
        description="Create and manage discount codes for your store."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Coupon Management</h1>
        <button className="mb-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary">
          Add New Coupon
        </button>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Code</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Discount</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Expires</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">WELCOME10</td>
              <td className="border-t px-4 py-2">10% off</td>
              <td className="border-t px-4 py-2">2025-12-31</td>
              <td className="border-t px-4 py-2">
                <button className="text-primary hover:underline mr-2">Edit</button>
                <button className="text-red-600 hover:underline">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
