import SeoHead from '../../components/SeoHead';

export default function AdminAnalytics() {
  return (
    <>
      <SeoHead
        title="Analytics Dashboard"
        description="Visualize key metrics such as sales, orders, traffic and inventory trends."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Analytics</h1>
        <p className="mb-4">Charts and graphs showing sales and inventory trends will be displayed here.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Sales by Month</h2>
            <p className="text-gray-700">Chart placeholder.</p>
          </div>
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Orders by Category</h2>
            <p className="text-gray-700">Chart placeholder.</p>
          </div>
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Blog Traffic</h2>
            <p className="text-gray-700">Chart placeholder.</p>
          </div>
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="font-semibold text-lg mb-2">Inventory Aging Report</h2>
            <p className="text-gray-700">Chart placeholder.</p>
          </div>
        </div>
      </div>
    </>
  );
}
