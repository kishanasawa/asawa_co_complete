import { useState } from 'react';
import SeoHead from '../../components/SeoHead';

export default function AdminGRN() {
  const [vendor, setVendor] = useState('');
  const [reference, setReference] = useState('');
  const [date, setDate] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('GRN creation is not yet implemented.');
  };
  return (
    <>
      <SeoHead
        title="GRN Management"
        description="Create and manage Goods Receipt Notes for inventory updates."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Goods Receipt Notes</h1>
        <form onSubmit={handleSubmit} className="bg-white shadow rounded-md p-6 mb-6 max-w-lg">
          <h2 className="text-xl font-semibold mb-4">Create GRN</h2>
          <div className="mb-4">
            <label htmlFor="vendor" className="block text-sm font-medium">Vendor</label>
            <input
              id="vendor"
              value={vendor}
              onChange={(e) => setVendor(e.target.value)}
              className="w-full border rounded-md p-2"
              placeholder="Vendor name"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="reference" className="block text-sm font-medium">Reference No.</label>
            <input
              id="reference"
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              className="w-full border rounded-md p-2"
              placeholder="Invoice or reference number"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="date" className="block text-sm font-medium">Date</label>
            <input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full border rounded-md p-2"
            />
          </div>
          <div className="mb-4">
            <label htmlFor="notes" className="block text-sm font-medium">Notes</label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full border rounded-md p-2"
              placeholder="Additional notes"
            ></textarea>
          </div>
          <button type="submit" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary">
            Create GRN
          </button>
        </form>
        <h2 className="text-xl font-semibold mb-4">Existing GRNs</h2>
        <p>List of GRNs will appear here.</p>
      </div>
    </>
  );
}
