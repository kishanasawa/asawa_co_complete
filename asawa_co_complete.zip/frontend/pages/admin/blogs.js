import SeoHead from '../../components/SeoHead';
import Link from 'next/link';

export default function AdminBlogs() {
  return (
    <>
      <SeoHead
        title="Blog Management"
        description="Create and manage blog posts and categories."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Blog Management</h1>
        <Link href="#" className="inline-block mb-4 px-4 py-2 bg-primary text-white rounded-md hover:bg-secondary">
          Add New Blog
        </Link>
        <p className="mb-4">A list of blog posts with options to edit and delete will be displayed here.</p>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Title</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Slug</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Published</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">Benefits of Whole Wheat Atta</td>
              <td className="border-t px-4 py-2">benefits-of-whole-wheat-atta</td>
              <td className="border-t px-4 py-2">Yes</td>
              <td className="border-t px-4 py-2">
                <button className="text-primary hover:underline mr-2">Edit</button>
                <button className="text-red-600 hover:underline">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
