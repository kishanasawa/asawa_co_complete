import SeoHead from '../../components/SeoHead';

export default function AdminOrders() {
  return (
    <>
      <SeoHead
        title="Order Management"
        description="View and manage customer orders and update their status."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Order Management</h1>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Order ID</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Customer</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Date</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Status</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">#1001</td>
              <td className="border-t px-4 py-2">John Doe</td>
              <td className="border-t px-4 py-2">2025-08-01</td>
              <td className="border-t px-4 py-2">Pending</td>
              <td className="border-t px-4 py-2">
                <button className="text-primary hover:underline mr-2">View</button>
                <button className="text-green-600 hover:underline mr-2">Mark as Shipped</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
