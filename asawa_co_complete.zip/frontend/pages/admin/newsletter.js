import SeoHead from '../../components/SeoHead';

export default function AdminNewsletter() {
  return (
    <>
      <SeoHead
        title="Newsletter Subscribers"
        description="Manage newsletter subscribers and send promotional emails."
      />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Newsletter Subscribers</h1>
        <p className="mb-4">View and manage subscribers who have signed up for updates.</p>
        <table className="min-w-full bg-white shadow rounded-lg">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2 text-left text-sm font-semibold">Email</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Subscribed At</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="border-t px-4 py-2">lead1@example.com</td>
              <td className="border-t px-4 py-2">2025-08-01</td>
              <td className="border-t px-4 py-2">
                <button className="text-red-600 hover:underline">Remove</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </>
  );
}
