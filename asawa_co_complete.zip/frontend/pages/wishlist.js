import SeoHead from '../components/SeoHead';

export default function Wishlist() {
  return (
    <>
      <SeoHead title="My Wishlist" description="Manage your saved products for later purchase." />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-4">My Wishlist</h1>
        <p>You have no items in your wishlist yet.</p>
      </div>
    </>
  );
}
