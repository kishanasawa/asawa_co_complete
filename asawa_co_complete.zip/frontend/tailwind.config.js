/**
 * TailwindCSS configuration.  This file specifies which files Tailwind should
 * scan for class names and defines the theme.  Feel free to customize the
 * colors, fonts and spacing scale as your brand evolves.
 */
module.exports = {
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#5a3e36', // earthy brown tone for ASAWA brand
        secondary: '#a87f5c', // lighter accent
        accent: '#e0c29a',
      },
    },
  },
  plugins: [],
};
