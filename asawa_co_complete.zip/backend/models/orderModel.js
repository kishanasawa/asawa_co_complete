import pool from '../config/db.js';

/**
 * Create a new order and its associated items.  This function wraps the insert
 * statements in a transaction so that items are rolled back if the order fails.
 * @param {number} userId ID of the user placing the order.
 * @param {Array} items List of items: {product_id, quantity, price}.
 * @param {string} [status] Optional initial status (e.g., 'pending').
 */
export async function createOrder(userId, items, status = 'pending') {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    // Create order
    const [orderResult] = await conn.query(
      'INSERT INTO orders (user_id, status, created_at) VALUES (?, ?, NOW())',
      [userId, status]
    );
    const orderId = orderResult.insertId;
    // Insert items
    for (const item of items) {
      const { product_id, quantity, price } = item;
      await conn.query(
        'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)',
        [orderId, product_id, quantity, price]
      );
    }
    await conn.commit();
    return orderId;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * Fetch all orders for a given user.
 * @param {number} userId
 */
export async function getOrdersByUser(userId) {
  const [rows] = await pool.query('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  return rows;
}

/**
 * Fetch an order with its items by ID.
 * @param {number} id Order ID
 */
export async function getOrderById(id) {
  const [orders] = await pool.query('SELECT * FROM orders WHERE id = ?', [id]);
  if (!orders.length) return null;
  const [items] = await pool.query('SELECT * FROM order_items WHERE order_id = ?', [id]);
  return { ...orders[0], items };
}

/**
 * Update order status.
 * @param {number} id Order ID
 * @param {string} status New status
 */
export async function updateOrderStatus(id, status) {
  const [result] = await pool.query('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
  return result.affectedRows > 0;
}
