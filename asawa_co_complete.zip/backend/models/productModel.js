import pool from '../config/db.js';

/**
 * Get all products with optional pagination.
 * @param {number} [limit] Maximum number of items to return.
 * @param {number} [offset] Offset for pagination.
 */
export async function getAllProducts(limit = 50, offset = 0) {
  const [rows] = await pool.query(
    'SELECT * FROM products ORDER BY created_at DESC LIMIT ? OFFSET ?',
    [limit, offset]
  );
  return rows;
}

/**
 * Get a single product by ID.
 * @param {number} id Product ID.
 */
export async function getProductById(id) {
  const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [id]);
  return rows[0] || null;
}

/**
 * Create a new product.
 * @param {object} product Product details.
 */
export async function createProduct(product) {
  const {
    name,
    description,
    price,
    category_id,
    stock_quantity,
    image_url,
    sku,
  } = product;
  const [result] = await pool.query(
    `INSERT INTO products (name, description, price, category_id, stock_quantity, image_url, sku)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [name, description, price, category_id, stock_quantity, image_url, sku]
  );
  return { id: result.insertId, ...product };
}

/**
 * Update a product by ID.
 * @param {number} id Product ID.
 * @param {object} updates Fields to update.
 */
export async function updateProduct(id, updates) {
  const fields = [];
  const values = [];
  Object.entries(updates).forEach(([key, value]) => {
    fields.push(`${key} = ?`);
    values.push(value);
  });
  if (fields.length === 0) return null;
  values.push(id);
  const [result] = await pool.query(
    `UPDATE products SET ${fields.join(', ')} WHERE id = ?`,
    values
  );
  return result.affectedRows > 0;
}

/**
 * Delete a product by ID.
 * @param {number} id Product ID.
 */
export async function deleteProduct(id) {
  const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);
  return result.affectedRows > 0;
}
