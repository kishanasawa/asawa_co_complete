import { verifyToken } from '../config/auth.js';
import { findUserById } from '../models/userModel.js';

/**
 * Middleware to authenticate requests using JWT.  The token should be supplied
 * in the Authorization header as `Bearer <token>`.
 */
export async function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization header missing' });
  }
  const token = authHeader.split(' ')[1];
  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
  // Optionally fetch user details from DB
  const user = await findUserById(decoded.id);
  if (!user) {
    return res.status(401).json({ message: 'User not found' });
  }
  req.user = user;
  next();
}
