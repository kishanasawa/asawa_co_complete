import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

// Create a reusable transporter using SMTP transport
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

/**
 * Send an email using the configured transporter.
 * @param {object} options Mail options (to, subject, html/text).
 */
export function sendMail(options) {
  const mailOptions = {
    from: process.env.FROM_EMAIL || process.env.SMTP_USER,
    ...options,
  };
  return transporter.sendMail(mailOptions);
}

export default transporter;
