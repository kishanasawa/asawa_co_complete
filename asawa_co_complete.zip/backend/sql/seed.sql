-- Seed data for ASAWA and Co. eCommerce platform

USE new_ecommerce;

-- Roles
INSERT INTO roles (name) VALUES ('customer'), ('admin') ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Users (admin and customer)
-- Passwords hashed for 'password123'
INSERT INTO users (id, name, email, password, role_id, phone)
VALUES
  (1, 'Admin User', 'admin@asawaandco.com', '$2a$10$KIX/5qzZ1bYH9iK9f3aOeu15Tz2C3zYQCBd1c1gqYfU0tVXpV4wzW', 2, '9000000000'),
  (2, 'John Doe', 'john@example.com', '$2a$10$KIX/5qzZ1bYH9iK9f3aOeu15Tz2C3zYQCBd1c1gqYfU0tVXpV4wzW', 1, '9876543210')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Admin table (linking user 1)
INSERT INTO admins (user_id) VALUES (1) ON DUPLICATE KEY UPDATE user_id = user_id;

-- Categories
INSERT INTO categories (id, name, slug, description)
VALUES
  (1, 'Atta', 'atta', 'Freshly milled flour varieties'),
  (2, 'Masala', 'masala', 'Authentic spice blends'),
  (3, 'Dry Fruits', 'dry-fruits', 'Premium quality dry fruits')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Products
INSERT INTO products (id, name, slug, sku, description, category_id, price, mrp, images, is_active)
VALUES
  (1, 'Whole Wheat Atta', 'whole-wheat-atta', 'ATTA-WW-1KG', 'Stone-ground whole wheat flour for soft rotis.', 1, 250.00, 280.00, JSON_ARRAY('https://example.com/img/atta1.jpg'), 1),
  (2, 'Multigrain Atta', 'multigrain-atta', 'ATTA-MG-1KG', 'Healthy blend of grains for extra nutrition.', 1, 300.00, 340.00, JSON_ARRAY('https://example.com/img/atta2.jpg'), 1),
  (3, 'Garam Masala', 'garam-masala', 'MAS-GM-100G', 'Traditional aromatic spice mix.', 2, 150.00, 170.00, JSON_ARRAY('https://example.com/img/garam1.jpg'), 1),
  (4, 'Haldi (Turmeric) Powder', 'haldi-powder', 'MAS-HAL-100G', 'Pure, high-curcumin turmeric powder.', 2, 120.00, 140.00, JSON_ARRAY('https://example.com/img/haldi1.jpg'), 1),
  (5, 'Almonds', 'almonds', 'DF-ALM-250G', 'Premium Californian almonds.', 3, 800.00, 900.00, JSON_ARRAY('https://example.com/img/almonds1.jpg'), 1)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Product variants
INSERT INTO product_variants (id, product_id, variant_name, price, sku, stock)
VALUES
  (1, 1, '1kg', 250.00, 'ATTA-WW-1KG', 50),
  (2, 1, '5kg', 1150.00, 'ATTA-WW-5KG', 20),
  (3, 2, '1kg', 300.00, 'ATTA-MG-1KG', 40),
  (4, 3, '100g', 150.00, 'MAS-GM-100G', 100),
  (5, 3, '500g', 650.00, 'MAS-GM-500G', 30),
  (6, 4, '100g', 120.00, 'MAS-HAL-100G', 120),
  (7, 5, '250g', 800.00, 'DF-ALM-250G', 25)
ON DUPLICATE KEY UPDATE variant_name = VALUES(variant_name);

-- Inventory
INSERT INTO inventory (id, product_id, variant_id, quantity, min_stock, max_stock)
VALUES
  (1, 1, 1, 50, 10, 200),
  (2, 1, 2, 20, 10, 200),
  (3, 2, 3, 40, 10, 200),
  (4, 3, 4, 100, 10, 200),
  (5, 3, 5, 30, 10, 200),
  (6, 4, 6, 120, 10, 200),
  (7, 5, 7, 25, 10, 200)
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);

-- Blogs
INSERT INTO blogs (id, title, slug, content, published, published_at, views)
VALUES
  (1, 'Benefits of Whole Wheat Atta', 'benefits-of-whole-wheat-atta', 'Whole wheat atta is rich in fiber and nutrients...', 1, NOW(), 10),
  (2, 'How to Choose Fresh Spices', 'how-to-choose-fresh-spices', 'Fresh spices enhance flavor and aroma...', 1, NOW(), 5),
  (3, 'Health Benefits of Dry Fruits', 'health-benefits-of-dry-fruits', 'Dry fruits are packed with essential vitamins and minerals...', 1, NOW(), 8)
ON DUPLICATE KEY UPDATE title = VALUES(title);

-- Blog tags
INSERT INTO blog_tags (id, blog_id, tag)
VALUES
  (1, 1, 'health'),
  (2, 2, 'spices'),
  (3, 3, 'nutrition')
ON DUPLICATE KEY UPDATE tag = VALUES(tag);

-- CMS Pages
INSERT INTO cms_pages (id, slug, title, content, is_active)
VALUES
  (1, 'about', 'About Us', 'Information about ASAWA and Co.', 1),
  (2, 'privacy-policy', 'Privacy Policy', 'Privacy policy details...', 1),
  (3, 'refund-policy', 'Refund Policy', 'Refund policy details...', 1),
  (4, 'shipping-policy', 'Shipping Policy', 'Shipping policy details...', 1),
  (5, 'terms-and-conditions', 'Terms & Conditions', 'Terms and conditions details...', 1)
ON DUPLICATE KEY UPDATE title = VALUES(title);

-- Coupons
INSERT INTO coupons (id, code, discount_type, discount_value, min_order_value, max_discount, starts_at, ends_at, usage_limit, used_count, active)
VALUES
  (1, 'WELCOME10', 'percent', 10.00, 0.00, 300.00, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 1000, 0, 1),
  (2, 'FESTIVE50', 'flat', 50.00, 300.00, NULL, NOW(), DATE_ADD(NOW(), INTERVAL 15 DAY), 1000, 0, 1),
  (3, 'HEALTHY20', 'percent', 20.00, 200.00, 500.00, NOW(), DATE_ADD(NOW(), INTERVAL 45 DAY), 500, 0, 1)
ON DUPLICATE KEY UPDATE discount_value = VALUES(discount_value);

-- Newsletter subscribers
INSERT INTO newsletter_subscribers (id, email, subscribed_at)
VALUES
  (1, 'lead1@example.com', NOW()),
  (2, 'lead2@example.com', NOW())
ON DUPLICATE KEY UPDATE email = VALUES(email);

-- Contacts (sample)
INSERT INTO contacts (id, name, email, message)
VALUES
  (1, 'Test User', 'test@example.com', 'Just saying hi!')
ON DUPLICATE KEY UPDATE message = VALUES(message);

-- Address for John
INSERT INTO addresses (id, user_id, full_name, phone, line1, line2, city, state, postal_code, country, is_default)
VALUES
  (1, 2, 'John Doe', '9876543210', '123 Market Street', 'Near Central Mall', 'Hyderabad', 'Telangana', '500001', 'India', 1)
ON DUPLICATE KEY UPDATE line1 = VALUES(line1);

-- Orders and order items
INSERT INTO orders (id, user_id, status, subtotal, discount, tax, total, payment_method, created_at, updated_at)
VALUES
  (1, 2, 'paid', 370.00, 0.00, 0.00, 370.00, 'COD', NOW(), NOW())
ON DUPLICATE KEY UPDATE status = VALUES(status);

INSERT INTO order_items (id, order_id, product_id, variant_id, quantity, price, line_total)
VALUES
  (1, 1, 1, 1, 1, 250.00, 250.00),
  (2, 1, 4, 6, 1, 120.00, 120.00)
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);

-- Invoices and invoice items
INSERT INTO invoices (id, order_id, invoice_number, date, total_amount, created_at)
VALUES
  (1, 1, 'INV-2025-0001', CURDATE(), 370.00, NOW())
ON DUPLICATE KEY UPDATE total_amount = VALUES(total_amount);

INSERT INTO invoice_items (id, invoice_id, product_id, quantity, price)
VALUES
  (1, 1, 1, 1, 250.00),
  (2, 1, 4, 1, 120.00)
ON DUPLICATE KEY UPDATE price = VALUES(price);
