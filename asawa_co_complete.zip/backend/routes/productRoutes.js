import { Router } from 'express';
import {
  listProducts,
  getProduct,
  addProduct,
  editProduct,
  removeProduct,
} from '../controllers/productController.js';
import { authenticate } from '../middleware/authMiddleware.js';
import { permitRoles } from '../middleware/roleMiddleware.js';

const router = Router();

// Public routes
router.get('/', listProducts);
router.get('/:id', getProduct);

// Admin routes (role_id 2 assumed for admin)
router.post('/', authenticate, permitRoles([2]), addProduct);
router.put('/:id', authenticate, permitRoles([2]), editProduct);
router.delete('/:id', authenticate, permitRoles([2]), removeProduct);

export default router;
